<?php
// Heading
$_['heading_title']				= 'Thank you for shopping with %s .... ';

// Text
$_['text_title'] = 'Яндекс.Деньги';
$_['text_method'] = 'Метод оплаты';
$_['text_method_ym'] = 'Яндекс.Деньги';
$_['text_method_cards'] = 'Банковская карта';
$_['text_method_cash'] = 'Наличными или в терминалах партнеров Яндекс.Денег';
$_['text_method_mobile'] = 'Оплата со счета сотового телефона';
$_['text_method_sber'] = 'Карта Сбербанк';
$_['text_method_alfa'] = 'Альфабанк';
$_['text_method_wm'] = 'WebMoney';
$_['text_order'] = 'Заказ';
$_['text_comment'] = 'Комментарий';
$_['wallet_ok_txt'] = 'Спасибо! Ваш заказ успешно оплачен. Мы приступили к его обработке.';
$_['text_back'] = 'Вернуться назад';