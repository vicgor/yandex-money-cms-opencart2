<?php
// Heading
$_['heading_title']				= 'Thank you for shopping with %s .... ';

// Text
$_['text_title'] = 'Яндекс.Деньги';
$_['text_method'] = 'Метод оплаты';
$_['text_method_ym'] = 'Яндекс.Деньги';
$_['text_method_cards'] = 'Банковские карты';
$_['text_method_cash'] = 'Наличными';
$_['text_method_mobile'] = 'Счет мобильного телефона';
$_['text_method_sber'] = 'Сбербанк Онлайн';
$_['text_method_alfa'] = 'Альфа-Клик';
$_['text_method_wm'] = 'WebMoney';
$_['text_order'] = 'Заказ';
$_['text_comment'] = 'Комментарий';
$_['wallet_ok_txt'] = 'Спасибо! Ваш заказ успешно оплачен. Мы приступили к его обработке.';
$_['text_back'] = 'Вернуться назад';