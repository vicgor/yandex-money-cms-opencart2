<?php
// Heading
$_['heading_title']					= 'Яндекс деньги дополнение';